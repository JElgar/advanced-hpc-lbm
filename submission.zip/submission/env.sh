module load languages/anaconda2
module load languages/gcc/9.1.0
module load languages/intel/2018-u3
